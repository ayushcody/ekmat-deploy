interface Window {
    ethereum: any;
}
